 "use client";

import { useMemo, useRef, useState } from "react";
import { ArrowDownToLine, ArrowRight, Bot, Check, ChevronDown, Code2, Eye, Laptop, LoaderCircle, MessageSquare, Monitor, Plus, Rocket, Send, Sparkles, Tablet, WandSparkles } from "lucide-react";

type Message = { role: "user" | "assistant"; content: string };
const starters = [
  { title: "Online store", detail: "A premium shop for products", prompt: "Build a premium online store for a modern lifestyle brand with product cards, categories, search, cart demo, and a responsive layout." },
  { title: "Portfolio", detail: "Showcase my work", prompt: "Build a polished personal portfolio with an intro hero, selected projects, skills, about section, contact form demo, and dark modern styling." },
  { title: "Business website", detail: "Get more customer enquiries", prompt: "Build a trustworthy small business website with a strong hero, services, testimonials, pricing, FAQ, and contact call-to-action." },
  { title: "SaaS landing page", detail: "Launch an app or product", prompt: "Build a high-converting SaaS landing page with product hero, feature grid, workflow section, pricing cards, testimonials, and FAQ." },
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi! I’m your MK19X website-building agent. Tell me what you want to create, even if it’s just a rough idea. I’ll help shape the brief one step at a time." }
  ]);
  const [input, setInput] = useState("");
  const [brief, setBrief] = useState("");
  const [html, setHtml] = useState("");
  const [busy, setBusy] = useState(false);
  const [building, setBuilding] = useState(false);
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [tab, setTab] = useState<"preview" | "code">("preview");
  const [error, setError] = useState("");
  const chatEnd = useRef<HTMLDivElement>(null);

  const conversationText = useMemo(() => messages.map(m => `${m.role === "user" ? "USER" : "AGENT"}: ${m.content}`).join("\n\n"), [messages]);

  async function sendMessage(text = input) {
    const content = text.trim();
    if (!content || busy) return;
    const next = [...messages, { role: "user" as const, content }];
    setMessages(next);
    setInput("");
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/agent", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not reach the agent.");
      setMessages([...next, { role: "assistant", content: data.reply }]);
      setTimeout(() => chatEnd.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 50);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
      setMessages(next);
    } finally { setBusy(false); }
  }

  async function buildWebsite() {
    const currentBrief = brief.trim() || conversationText;
    if (currentBrief.length < 10 || building) return;
    setBuilding(true); setError("");
    try {
      const res = await fetch("/api/build", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ brief: currentBrief }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Website generation failed.");
      setHtml(data.html);
      setTab("preview");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally { setBuilding(false); }
  }

  function downloadHtml() {
    if (!html) return;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "mk19x-website.html"; a.click();
    URL.revokeObjectURL(url);
  }

  function downloadBrief() {
    const content = `MK19X WEBSITE BRIEF\n\n${brief || conversationText}\n\nGenerated prototype is a frontend demo. Review before production deployment.`;
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "website-brief.txt"; a.click(); URL.revokeObjectURL(url);
  }

  function reset() {
    setMessages([{ role: "assistant", content: "New project started. What would you like your website to do?" }]);
    setInput(""); setBrief(""); setHtml(""); setError(""); setTab("preview");
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-mark">MK<span>19</span>X</span><span className="brand-divider" /><span className="brand-label">STUDIO</span></a>
        <div className="top-status"><span className="status-dot" /> AI WEBSITE BUILDER <span className="top-pill">BETA</span></div>
        <button className="new-project" onClick={reset}><Plus size={16} /> <span>New project</span></button>
      </header>

      <section className="hero">
        <div className="eyebrow"><Sparkles size={14} /> YOUR IDEA, BUILT WITH AI</div>
        <h1>From a thought to a <span>website.</span></h1>
        <p>Describe what you imagine. Your AI agent helps plan it, builds a first version, and gives you a live preview you can export.</p>
      </section>

      <section className="workspace">
        <aside className="panel chat-panel">
          <div className="panel-head">
            <div className="panel-title"><span className="agent-avatar"><Bot size={18} /></span><div><strong>Your website agent</strong><small>Planning & creation</small></div></div>
            <span className="online-label"><span className="status-dot" /> ONLINE</span>
          </div>
          <div className="chat-body">
            <div className="messages">
              {messages.map((m, i) => <div className={`message-row ${m.role}`} key={i}>
                {m.role === "assistant" && <span className="mini-avatar"><Sparkles size={13} /></span>}
                <div className="message-bubble">{m.content}</div>
              </div>)}
              {busy && <div className="message-row assistant"><span className="mini-avatar"><Sparkles size={13} /></span><div className="message-bubble typing"><span /><span /><span /></div></div>}
              <div ref={chatEnd} />
            </div>
            {messages.length <= 1 && <div className="starter-section"><span className="starter-label">OR START WITH A TEMPLATE IDEA</span><div className="starter-grid">{starters.map(s => <button key={s.title} className="starter-card" onClick={() => sendMessage(s.prompt)}><span>{s.title}</span><small>{s.detail}</small><ArrowRight size={14} /></button>)}</div></div>}
          </div>
          <div className="chat-compose">
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }} placeholder="Describe your website idea…" rows={2} />
            <button className="send-button" onClick={() => sendMessage()} disabled={!input.trim() || busy} aria-label="Send message">{busy ? <LoaderCircle className="spin" size={17} /> : <Send size={17} />}</button>
            <div className="compose-hint"><span>Enter to send · Shift + Enter for new line</span><span><MessageSquare size={12} /> Guided discovery</span></div>
          </div>
        </aside>

        <section className="panel preview-panel">
          <div className="preview-top">
            <div className="preview-title"><span className="preview-icon"><Eye size={16} /></span><div><strong>Live workspace</strong><small>{html ? "Your generated website" : "Your preview will appear here"}</small></div></div>
            <div className="preview-controls">
              <button className={`icon-control ${device === "desktop" ? "selected" : ""}`} onClick={() => setDevice("desktop")} title="Desktop preview"><Monitor size={16} /></button>
              <button className={`icon-control ${device === "mobile" ? "selected" : ""}`} onClick={() => setDevice("mobile")} title="Mobile preview"><Tablet size={16} /></button>
            </div>
          </div>
          <div className="preview-toolbar"><div className="window-dots"><i /><i /><i /></div><div className="fake-url"><span className="lock">⌑</span> preview.mk19x.local / your-site</div><button className="refresh-button" onClick={() => setTab("preview")}><ArrowDownToLine size={13} /> <span>Preview</span></button></div>
          <div className="preview-stage">
            {html ? <div className={`site-frame ${device}`} key={device}>
              {tab === "preview" ? <iframe title="Generated website preview" srcDoc={html} sandbox="allow-scripts" /> : <pre className="code-view"><code>{html}</code></pre>}
            </div> : <div className="empty-preview">
              <div className="preview-orbit"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit-core"><WandSparkles size={27} /></div><span className="orbit-spark spark-a">✦</span><span className="orbit-spark spark-b">✧</span></div>
              <h3>Your canvas is waiting</h3><p>Chat with your agent to shape the idea, then build your first version.</p>
              <div className="preview-steps"><div><span>01</span> Describe</div><ArrowRight size={13} /><div><span>02</span> Generate</div><ArrowRight size={13} /><div><span>03</span> Export</div></div>
            </div>}
          </div>
          <div className="preview-footer">
            <div className="preview-footer-left"><span className="footer-dot" /> {html ? "Prototype generated" : "Ready to build"} <span className="footer-separator">·</span> <span>Responsive canvas</span></div>
            <div className="footer-actions">
              {html && <button className="secondary-button" onClick={() => setTab(tab === "preview" ? "code" : "preview")}><Code2 size={14} /> {tab === "preview" ? "View code" : "View site"}</button>}
              <button className="secondary-button" onClick={downloadBrief}><ArrowDownToLine size={14} /> Brief</button>
              <button className="export-button" onClick={downloadHtml} disabled={!html}><ArrowDownToLine size={15} /> Export HTML</button>
            </div>
          </div>
        </section>
      </section>

      <section className="build-strip">
        <div className="build-copy"><div className="build-icon"><Rocket size={19} /></div><div><strong>Ready to bring it to life?</strong><p>Build a responsive first version from your conversation or edit the brief directly.</p></div></div>
        <div className="build-action">
          <textarea value={brief} onChange={e => setBrief(e.target.value)} placeholder="Optional: refine your brief here (audience, pages, style, features…)" rows={2} />
          <button className="build-button" onClick={buildWebsite} disabled={building || (!brief.trim() && messages.length < 2)}>{building ? <><LoaderCircle size={17} className="spin" /> Building…</> : <><WandSparkles size={17} /> Build website <ArrowRight size={16} /></>}</button>
        </div>
      </section>

      {error && <div className="error-banner" role="alert">{error}<button onClick={() => setError("")}>Dismiss</button></div>}

      <footer className="page-footer"><div>MK<span>19</span>X <span className="footer-muted">STUDIO</span></div><span>Made for people with ideas — not just developers.</span><span className="footer-muted">AI-GENERATED PROTOTYPES · REVIEW BEFORE LAUNCH</span></footer>
    </main>
  );
}