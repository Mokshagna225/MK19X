import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MK19X — Agentic Website Builder",
  description: "Describe your idea. Build a website with an AI agent.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}